export interface SkillDTO {
  id: number;
  user_id: string;
  name: string;
  category: string;
  icon_url: string;
  created_at: Date;
}
