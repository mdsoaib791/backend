export interface ExperienceDTO {
  id: number;
  user_id: string;
  company: string;
  position: string;
  description: string;
  start_date: Date;
  end_date?: Date;
  created_at: Date;
}
