export interface ProjectDTO {
  id: number;
  user_id: string;
  title: string;
  description: string;
  tech_stack: string[];
  github_url?: string;
  live_url?: string;
  thumbnail?: string;
  created_at: Date;
}
