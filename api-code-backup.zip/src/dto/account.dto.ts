export interface AccountDTO {
user_id: string;
  email: string;
  role: string;
  created_at: Date;
  updated_at: Date;
}
