export interface Account {
  id: number;
  email: string;
  password: string;
  role: string;
  created_at: Date;
}
