export interface Class {
  id: number;
  name: string;
  section: string | null;
  created_at: Date;
}
