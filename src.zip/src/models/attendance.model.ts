export interface Attendance {
  id: number;
  student_id: number;
  date: Date;
  status: string;
}
