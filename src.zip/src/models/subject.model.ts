export interface Subject {
  id: number;
  name: string;
  code: string;
  created_at: Date;
}
