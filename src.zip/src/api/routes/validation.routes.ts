import express from 'express';

const router = express.Router();

// All validation removed. Add new endpoints here if needed.

export default router;
