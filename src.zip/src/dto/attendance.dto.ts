export interface AttendanceDTO {
  id: number;
  student_id: number;
  date: Date;
  status: string;
}
